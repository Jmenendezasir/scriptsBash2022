#!/bin/bash

clear
read -p "¿Qué fichero quieres borrar? " fichero

if [[ $fichero == "ninguno" ]]
then
	clear
	echo "Recibido, saliendo..."
	sleep .5
	exit
fi

rm $fichero

clear
echo ""
echo "Eliminando el archivo."
sleep .5
clear
echo ""
echo "Eliminando el archivo.."
sleep .5
clear
echo ""
echo "Eliminando el archivo..."
sleep .5
clear
echo ""
echo "Eliminando el archivo."
sleep .5
clear
echo ""
echo "El fichero $fichero ha sido eliminado correctamente..."
echo ""
echo ""
sleep .5
date >> eliminado.log
echo $fichero >> eliminado.log
echo "______________________" >> eliminado.log
