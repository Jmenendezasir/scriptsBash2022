#!/bin/bash

clear

echo "--------------"
echo " EJERCICIO 1  "
echo "--------------"
echo ""
echo "Nombre del equipo: `hostname`"
echo ""
echo "Nombre del usuario: `whoami`"
echo ""
echo "Grupos a los que pertenece `whoami`: `groups`"
