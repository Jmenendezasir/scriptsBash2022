#!/bin/bash

clear

echo "------------"
echo " EJERCICIOS "
echo "------------"
echo ""
echo "Selecciona tu ejercicio."
echo ""
echo "1. Nombre del equipo y grupo"
echo "2. Backup del directorio HOME"
echo "3. Calculadora"
echo "4. Permisos de lectura"
echo "5. Copiar ficheros .dat y .c"
echo "6. Listado recursivo de un directorio"
echo "7. Comprobar si es fichero o directorio"
echo "8. Comprobar tamaño de un fichero o directorio"
echo "9. Comprimir ficheros del directorio actual"
echo "10. Ordenar el contenido de un fichero."
echo ""
read -p "Selecciona un ejercicio: " EJERCICIO

if [ $EJERCICIO = "1" ]
then
    ./1.sh
fi

if [ $EJERCICIO = "2" ]
then
    ./2.sh
fi
