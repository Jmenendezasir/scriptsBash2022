#!/bin/bash

echo "Dime tu nombre:"

read NOMBRE

echo "¿Tu nombre es $NOMBRE? si/no"

read RESPUESTA

if [[ $RESPUESTA == "si" ]]
then
	echo "Correcto, tu nombre es $NOMBRE"
else
	if [[ $RESPUESTA == "no" ]]
	then
		./leer.sh
	fi
fi
