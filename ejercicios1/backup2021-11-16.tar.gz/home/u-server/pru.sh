#!/bin/bash
# Autor: Jose
# Fecha: 02/11/2021
# Descripción: Trabajar con parámetros

echo "Nombre del script:" $0
echo "Primer parámetro" $1
echo "Segundo parámetro:" $2
echo "Todos los parámetros" $*
echo "Número total de parámetros" $#
echo ""


if [[ $# < 1 ]]
then
	echo "No hay parámetros"
else
	echo "Hay demasiados parámetros"
fi
